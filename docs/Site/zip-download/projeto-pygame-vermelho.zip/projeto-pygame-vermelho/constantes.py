'''
    Arquivo com as constantes do jogo
'''
BRANCO = (255, 255, 255)
PRETO = (0, 0, 0)
VERDE = (0, 255, 0)
VERMELHO = (255, 0, 0)
AZUL = (0, 0, 255)



TELA_LARGURA = 1200
TELA_ALTURA = 600

STILL = 0
JUMPING = 1